#pragma once

class CSndObject
{
public:
	CSndObject(void);
	virtual ~CSndObject(void);
};
