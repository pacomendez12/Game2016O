#include "StdAfx.h"
#include "ObjectModel3D.h"


CObjectModel3D::CObjectModel3D(void)
{
}


CObjectModel3D::~CObjectModel3D(void)
{
}
