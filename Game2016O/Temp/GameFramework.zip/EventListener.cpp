#include "StdAfx.h"
#include "EventListener.h"


CEventListener::CEventListener(void)
{
}


CEventListener::~CEventListener(void)
{
}
