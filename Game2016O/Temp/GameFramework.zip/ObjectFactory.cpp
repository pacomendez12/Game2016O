#include "StdAfx.h"
#include "ObjectFactory.h"


CObjectFactory::CObjectFactory(void)
{
}


CObjectFactory::~CObjectFactory(void)
{
}
