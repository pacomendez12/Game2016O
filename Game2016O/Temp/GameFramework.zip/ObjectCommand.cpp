#include "StdAfx.h"
#include "ObjectCommand.h"


CObjectCommand::CObjectCommand(void)
{
}


CObjectCommand::~CObjectCommand(void)
{
}
