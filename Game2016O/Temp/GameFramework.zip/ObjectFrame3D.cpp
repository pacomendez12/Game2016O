#include "StdAfx.h"
#include "ObjectFrame3D.h"


CObjectFrame3D::CObjectFrame3D(void)
{
}


CObjectFrame3D::~CObjectFrame3D(void)
{
}
