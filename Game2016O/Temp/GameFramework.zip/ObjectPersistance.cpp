#include "StdAfx.h"
#include "ObjectPersistance.h"


CObjectPersistance::CObjectPersistance(void)
{
}


CObjectPersistance::~CObjectPersistance(void)
{
}
