#include "StdAfx.h"
#include "Filter.h"

CFilter::CFilter()
{
	m_SamplingFreq=0;
	m_CutFreq=0;
}

CFilter::~CFilter(void)
{
}
