#include "stdafx.h"
#include "EventCtrl.h"


CEventCtrl::CEventCtrl(void)
{
	m_ulEventType=EVENT_CTRL;
	m_fParam=0.0f;
}


CEventCtrl::~CEventCtrl(void)
{
}
