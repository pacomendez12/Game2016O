#include "StdAfx.h"
#include "SndObject.h"

CSndObject::CSndObject(void)
{
}

CSndObject::~CSndObject(void)
{
}
