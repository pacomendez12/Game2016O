#include "StdAfx.h"
#include "EventBase.h"


CEventBase::CEventBase(void)
{
}


CEventBase::~CEventBase(void)
{
}
