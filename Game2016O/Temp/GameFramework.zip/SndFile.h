#pragma once
#include "sndobject.h"

class CSndFile :
	public CSndObject
{
protected:
	CSndFile(void);
	virtual ~CSndFile(void);
public:
};
