#pragma once
#include "gfxstandard.h"
class CGFXStandardHQ :
	public CGFXStandard
{
public:
	CGFXStandardHQ(CDXGIManager* pManager);
	virtual ~CGFXStandardHQ(void);
};

